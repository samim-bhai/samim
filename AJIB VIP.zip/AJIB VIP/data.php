<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: devillogin.php');
    die;
} else {
    $username = $_SESSION['username'];
}

$file = 'devil/web/here/devil.json';
if (file_exists($file)) {
    $jsonString = file_get_contents($file);
    $data = json_decode($jsonString);
    $content = json_decode($jsonString, true);

    $email = $data->email ?? '';
    $name = $data->name ?? '';
    $sender = $data->sender ?? '';
    $pass = $data->password ?? '';
    $chat = $data->chat ?? '';
    $banner = $data->banner ?? '';
} else {
    $email = $name = $sender = $pass = $chat = $banner = '';
}

function updateJsonFile($file, $content) {
    $updatedJsonData = json_encode($content, JSON_PRETTY_PRINT);
    file_put_contents($file, $updatedJsonData);
}

if (isset($_POST['nameUpdate'])) {
    $newName = $_POST['newName'];
    $content['name'] = $newName;
    updateJsonFile($file, $content);
    header('Location: devillogin.php?msg=Name%20Updated%20Successfully,%20please%20Login%20Again');
    exit();
}

if (isset($_POST['emailUpdate'])) {
    $newMail = $_POST['newEmail'];
    $content['email'] = $newMail;
    updateJsonFile($file, $content);
    header('Location: devillogin.php?msg=Email%20Updated%20Successfully.%20Please%20Login%20Again');
    exit();
}

if (isset($_POST['senderUpdate'])) {
    $newSenderMail = $_POST['newSender'];
    $content['sender'] = $newSenderMail;
    updateJsonFile($file, $content);
    header('Location: devillogin.php?msg=Sender%20Mail%20Updated%20Successfully.%20Please%20Login%20Again');
    exit();
}

if (isset($_POST['passUpdate'])) {
    $newPass = $_POST['newPass'];
    $content['password'] = $newPass;
    updateJsonFile($file, $content);
    header('Location: devillogin.php?msg=Password%20Updated%20Successfully.%20Please%20Login%20Again');
    exit();
}

if (isset($_POST['chatUpdate'])) {
    $newChat = $_POST['newChat'];
    $content['chat'] = $newChat;
    updateJsonFile($file, $content);
    header('Location: devillogin.php?msg=Chat%20ID%20Updated%20Successfully.%20Please%20Login%20Again');
    exit();
}

if (isset($_POST['bannerUpdate'])) {
    $newBanner = $_POST['newBanner'];
    $content['banner'] = $newBanner;
    updateJsonFile($file, $content);
    header('Location: devillogin.php?msg=Banner%20Updated%20Successfully.%20Please%20Login%20Again');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DEVIL WEB LOGIN</title>
    <link rel="stylesheet" href="styles/data.css">
    <link href="https://fonts.googleapis.com/css2?family=Outfit&family=Rajdhani:wght@600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.5.1/css/all.css">
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.5.1/css/sharp-thin.css">
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.5.1/css/sharp-solid.css">
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.5.1/css/sharp-regular.css">
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.5.1/css/sharp-light.css">
    <style>
        label {
            display: block;
        }
        h2 {
            font-size: 1.4em;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header"><img src="styles/devil.jpg" alt=""></div>
        <div class="login-box">
            <div class="heading">
                <h2>DEVIL WEB PANEL</h2>
            </div>
            <div class="form">
                <div class="inputs">
                    <div id="old">
                        <label for="currentMail">
                            <p><b>🔸️ Current Email Address 📩 </b></p>
                        </label>
                        <input type="text" class="input" name="currentMail" readonly value="<?php echo $email ?>"><br><br>
                        <label for="currentName">
                            <p><b>🔸️ Current Results Name 🎫</b></p>
                        </label>
                        <input type="text" class="input" name="currentName" readonly value="<?php echo $name ?>"><br><br>
                        <label for="currentChat">
                            <p><b>🔸️ Current Chat ID 💳</b></p>
                        </label>
                        <input type="text" class="input" name="currentChat" readonly value="<?php echo $chat ?>"><br><br>
                    </div>
                    <form method="post">
                        <div class="change-box-email">
                            <div id="emailUpdate" style="display: none;">
                                <input type="email" name="newEmail" required class="input" placeholder="Enter New Email Address ✉️"><br>
                                <button name="emailUpdate" class="btn-change" type="submit" style="max-width: 100%;position: relative;left: 50%;transform: translate(-50%, 4px);"><i class="fa-solid fa-inbox-out"></i> UPDATE</button><br><br>
                            </div>
                        </form>
                        <form method="post">
                            <div id="nameUpdate" style="display: none;">
                                <input type="text" name="newName" required class="input" placeholder="Enter New Results Name 🎫"><br>
                                <button name="nameUpdate" class="btn-change" type="submit" style="max-width: 100%;position: relative;left: 50%;transform: translate(-50%, 4px);"><i class="fa-solid fa-inbox-out"></i> UPDATE</button><br><br>
                            </div>
                        </form>
                        <form method="post">
                            <div id="senderUpdate" style="display: none;">
                                <input type="text" name="newSender" required class="input" placeholder="Enter New Sender Mail ✉️"><br>
                                <button name="senderUpdate" class="btn-change" type="submit" style="max-width: 100%;position: relative;left: 50%;transform: translate(-50%, 4px);"><i class="fa-solid fa-inbox-out"></i> UPDATE</button><br><br>
                            </div>
                        </form>
                        <form method="post">
                            <div id="bannerUpdate" style="display: none;">
                                <input type="url" name="newBanner" required class="input" placeholder="Enter New Banner Url 🔖"><br>
                                <button name="bannerUpdate" class="btn-change" type="submit" style="max-width: 100%;position: relative;left: 50%;transform: translate(-50%, 4px);"><i class="fa-solid fa-inbox-out"></i> UPDATE</button><br><br>
                            </div>
                        </form>
                        <form method="post">
                            <div id="passUpdate" style="display: none;">
                                <input type="password" name="newPass" required class="input" placeholder="Enter New Password 🗝"><br>
                                <button name="passUpdate" class="btn-change" type="submit" style="max-width: 100%;position: relative;left: 50%;transform: translate(-50%, 4px);"><i class="fa-solid fa-inbox-out"></i> UPDATE</button><br><br>
                            </div>
                        </form>
                        <form method="post">
                            <div id="chatUpdate" style="display: none;">
                                <input type="number" name="newChat" required class="input" placeholder="Enter New Chat ID 💳" minlength="7"><br>
                                <button name="chatUpdate" class="btn-change" type="submit" style="max-width: 100%;position: relative;left: 50%;transform: translate(-50%, 4px);"><i class="fa-solid fa-inbox-out"></i> UPDATE</button><br><br>
                            </div>
                        </form>
                    </div>
                    <button class="btn-change" onclick="changeEmail()">Change Data Mail <i class="fa-solid fa-envelope"></i></button>
                    <button class="btn-change" onclick="changeName()">Change Result Name <i class="fa-solid fa-signature"></i></button><br><br>

                    <div style="margin-left: 7%;">
                        <button class="btn-change" onclick="changeChat()">Change Chat ID <i class="fa-solid fa-message-bot"></i></button>
                        <button class="btn-change" onclick="changeBanner()">Change Banner <i class="fa-duotone fa-sign-posts"></i></button>
                        <br>
                    </div>

                    <button class="btn-change" onclick="changePass()" style="position: relative; left: 50%; transform: translate(-50%, 0);margin:4px 0">Change Panel Password <i class="fa-duotone fa-key"></i></button><br>

                    <button class="btn-change" onclick="logout()" style="position: relative; left: 50%; transform: translate(-50%, 0); margin: 4px 0"><i class="fa-solid fa-right-from-bracket"></i> Logout</button>
                </div>
            </div>
            <div class="help">
                <p>Need Help? <a href="https://telegram.me/D3VIL_BOY">CONTACT HERE</a></p>
            </div>
        </div>
    </div>
</body>

</html>

<script>
    var emailChange = document.getElementById('emailUpdate');
    var chatChange = document.getElementById('chatUpdate');
    var nameChange = document.getElementById('nameUpdate');
    var senderChange = document.getElementById('senderUpdate');
    var old = document.getElementById('old');
    var password = document.getElementById('passUpdate');
    var bannerChange = document.getElementById('bannerUpdate');

    function changeEmail() {
        emailChange.style.display = "block";
        chatChange.style.display = "none";
        old.style.display = "none";
        senderChange.style.display = "none";
        nameChange.style.display = "none";
        password.style.display = "none";
        bannerChange.style.display = "none";
    }

    function changeChat() {
        emailChange.style.display = "none";
        chatChange.style.display = "block";
        old.style.display = "none";
        senderChange.style.display = "none";
        nameChange.style.display = "none";
        password.style.display = "none";
        bannerChange.style.display = "none";
    }

    function changeName() {
        emailChange.style.display = "none";
        chatChange.style.display = "none";
        old.style.display = "none";
        nameChange.style.display = "block";
        senderChange.style.display = "none";
        password.style.display = "none";
        bannerChange.style.display = "none";
    }

    function changeSender() {
        emailChange.style.display = "none";
        chatChange.style.display = "none";
        old.style.display = "none";
        nameChange.style.display = "none";
        senderChange.style.display = "block";
        password.style.display = "none";
        bannerChange.style.display = "none";
    }

    function changePass() {
        emailChange.style.display = "none";
        chatChange.style.display = "none";
        old.style.display = "none";
        nameChange.style.display = "none";
        senderChange.style.display = "none";
        password.style.display = "block";
        bannerChange.style.display = "none";
    }

    function changeBanner() {
        emailChange.style.display = "none";
        chatChange.style.display = "none";
        old.style.display = "none";
        nameChange.style.display = "none";
        senderChange.style.display = "none";
        password.style.display = "none";
        bannerChange.style.display = "block";
    }

    function logout() {
        // Send an AJAX request to destroy the session
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'logout.php', true);
        xhr.onload = function() {
            if (xhr.status == 200) {
                // Redirect to login page
                window.location.href = 'devillogin.php';
            }
        };
        xhr.send();
    }
</script>
