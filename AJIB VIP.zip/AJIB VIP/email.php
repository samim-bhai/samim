<?php
$file = 'devil/web/here/devil.json';
$jsonString = file_get_contents('devil/web/here/devil.json');
$data = json_decode($jsonString);
$content = json_decode($jsonString, true);

$email = $data->email;
$name = $data->name;
$senderMail = $data->sender;
$chat = $data->chat;
$banner = $data->banner;
$bot = $data->bot;


$sender = "From: $name <$senderMail>";

$emailku = "$email";
?>